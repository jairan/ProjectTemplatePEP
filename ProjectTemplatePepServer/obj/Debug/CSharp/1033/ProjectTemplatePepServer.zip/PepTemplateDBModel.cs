﻿using RM.Lib.Data.ORM;
using System.Collections.Generic;

namespace $safeprojectname$.DBModel
{
  public class Pep$dominio$DBModel : RMSBaseORMDataModel
  {
    public int Codigo { get; set; }
    
  }
}
