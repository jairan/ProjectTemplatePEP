﻿using RM.Lib.Data.ORM.SQL;

namespace $safeprojectname$.Queries
{
  public class Pep$dominio$Queries
  {
    public static string Listar$dominio$s(ISqlDialect dialeto) => $@"";

    public static string Detalhar(ISqlDialect dialeto) => $@"";

    public static string Colunas$dominio$ => $@"SZ$dominio$.CODIGO, ";
  }
}
