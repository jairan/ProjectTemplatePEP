﻿namespace $safeprojectname$.Model
{
  public class Pep$dominio$Negocio
  {
    public int Codigo { get; set; }
  }
}
