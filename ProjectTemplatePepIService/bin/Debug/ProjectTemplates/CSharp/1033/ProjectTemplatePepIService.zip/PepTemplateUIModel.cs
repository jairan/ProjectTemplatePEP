﻿using System.Collections.Generic;

namespace $safeprojectname$.Model
{
  public class Pep$dominio$UIModel
  {
    public int Codigo { get; set; }
  }
}
