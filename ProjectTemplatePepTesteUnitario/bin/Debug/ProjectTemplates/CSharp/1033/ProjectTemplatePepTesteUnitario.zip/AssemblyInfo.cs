﻿using RM.Lib;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("$safeprojectname$")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("TOTVS S.A.")]
[assembly: AssemblyProduct("RM")]
[assembly: AssemblyCopyright("Copyright © TOTVS $year$")]
[assembly: AssemblyTrademark("TOTVS S.A.")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("$guid1$")]

// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("$versao$")]
[assembly: AssemblyFileVersion("$versao$")]
[assembly: NeutralResourcesLanguageAttribute("pt-BR")]
[assembly: AssemblyLayerSide(LayerSideKind.TestesUnitarios)]
